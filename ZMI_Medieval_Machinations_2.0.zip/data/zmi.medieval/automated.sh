#/bin/bash
#path
if [ -z "$1" ]; then
	echo "You need to input a valid file path (Arg 1)"
	exit 0
else
	cd ./functions
	cd ./$1
	NAMES="$(echo `ls`)"
	NAMES="$(echo "${NAMES//.mcfunction}")"
	IFS=' ' read -r -a NAMES <<< "$NAMES"
	cd ../
	cd ../
fi
#custom #
if [ -z "$2" ]; then
	echo "You have not inputted a custom # (Arg 2). Defaulting to custom as specified by /render"
	cd ./functions/render
	CUSTOM="$(ls | grep -m 1 custom)"
	CUSTOM="$(echo "${CUSTOM//.mcfunction}")"
	CUSTOM="$(echo "${CUSTOM//custom}")"
	echo "$CUSTOM"
	cd ../
	cd ../
else
	CUSTOM=$2
	cd ./functions/render
	ToChange="$(echo `ls`)"
	mv ./$ToChange ./custom"$CUSTOM".mcfunction
	cd ../
	cd ../
	#Spawneggs in /crafts/	
	cd ./functions/crafts
	ToChange="$(echo `ls`)"
	mv ./$ToChange ./custom"$CUSTOM".mcfunction
	cd ../
	cd ../
	#Spawneggs	
	cd ./functions/spawneggs
	ToChange="$(echo `ls`)"
	mv ./$ToChange ./custom"$CUSTOM".mcfunction
	cd ../
	cd ../
	#load
	cd ./functions/load
	ToChange="$(echo `ls`)"
	mv ./$ToChange ./custom"$CUSTOM".mcfunction
	cd ../
	cd ../
fi

#Make Directories
mkdir ./recipes
mkdir ./functions/crafts
mkdir ./functions/spawneggs
mkdir ./advancements

#Crafts Automation
cd ./functions/crafts

if test -f "./crafted"$CUSTOM".mcfunction"; then
		:  		
		#echo "Craft $STRING exists already, skipping!"
	else
for i in ${!NAMES[@]}
do
	#get a path without all the ./
	PATH="$(echo "${1//\.\/}")"		
	#get the current name
	NAME="$(echo "${NAMES[$i]}")"
	#set the string, pipe to file
	STRING=$PATH"_"$NAME
	 
		echo " 
give @s[advancements={zmi:"$STRING"_adv = true}] wither_skeleton_spawn_egg{EntityTag:{id:\"minecraft:bat\",CustomName:\"\\\""$STRING"\\\"\",CustomNameVisible:1,NoAI:1b,Glowing:1,NoGravity:1b,CanPickUpLoot:1b,Health:1,Attributes:[{Name:\"generic.maxHealth\",Base:1}],Silent:1},DeathLootTable:\"minecraft:empty\",display:{Name:\"\\\"$STRING\\\"\"}}
recipe take @s zmi:"$STRING"
advancement revoke @s only zmi:"$STRING"_adv" >> ./"crafted"$CUSTOM".mcfunction"
done

echo "clear @s knowledge_book" >> ./"crafted"$CUSTOM".mcfunction"
fi
cd ../
cd ../

#Spawneggs in /crafts/ automation
cd ./functions/crafts

if test -f "./custom"$CUSTOM".mcfunction"; then
	:	
	#echo "Crafts spawnegg thing exists already, skipping"
else
	for i in ${!NAMES[@]}
	do
		#get a path without all the ./
		PATH="$(echo "${1//.\/}")"		
		#get the current name
		NAME="$(echo "${NAMES[$i]}")"
		#set the string, pipe to file
		STRING=$PATH"_"$NAME
		echo "
execute as @e[type=bat,name=$STRING] at @s run function zmi:$PATH/$NAME
kill @e[type=bat,name=$STRING]" >> ./"custom$CUSTOM"".mcfunction"
	done
fi

cd ../
cd ../

#Spawneggs Automation
cd ./functions/spawneggs

if test -f "./custom"$CUSTOM".mcfunction"; then
	:	
	#echo "spawnegg thing exists already, skipping"
else
	for i in ${!NAMES[@]}
	do
		#get a path without all the ./
		PATH="$(echo "${1//.\/}")"		
		#get the current name
		NAME="$(echo "${NAMES[$i]}")"
		#set the string, pipe to file
		STRING=$PATH"_"$NAME
		echo " 
give @s wither_skeleton_spawn_egg{EntityTag:{id:\"minecraft:bat\",CustomName:\"\\\""$STRING"\\\"\",CustomNameVisible:1,NoAI:1b,Glowing:1,NoGravity:1b,CanPickUpLoot:1b,Health:1,Attributes:[{Name:\"generic.maxHealth\",Base:1}],Silent:1},DeathLootTable:\"minecraft:empty\",display:{Name:\"\\\"$STRING\\\"\"}}" >> ./"custom$CUSTOM"".mcfunction"
	done
fi

cd ../
cd ../



#head to advancements
cd ./advancements

for i in ${!NAMES[@]}
do
	#get a path without all the ./
	PATH="$(echo "${1//.\/}")"		
	#get the current name
	NAME="$(echo "${NAMES[$i]}")"
	#set the string, pipe to file
	STRING=$PATH"_"$NAME
	if test -f "./$STRING"_adv.json""; then
		:  		
		#echo "Advancement $STRING exists already, skipping!"
	else 
		echo "
{
    \"criteria\": {
        \"Unlocked\": {
            \"trigger\": \"minecraft:recipe_unlocked\",
            \"conditions\": {
                \"recipe\": \"zmi:"$STRING"\"
            }
        }
    },
    \"rewards\": {
        \"function\": \"zmi:crafts/crafted"$CUSTOM"\"
    }
}
" >> ./"$STRING""_adv.json"
	fi
done
cd ../


#head to recipes
cd ./recipes

for i in ${!NAMES[@]}
do
	#get a path without all the ./
	PATH="$(echo "${1//.\/}")"			
	#get the current name
	NAME="$(echo "${NAMES[$i]}")"
	#set the string, pipe to file
	STRING=$PATH"_"$NAME
	if test -f "./$STRING".json""; then
		:  		
		#echo "Recipe $STRING exists already, skipping!"
	else 
		echo "
put a recipe file here
" >> ./"$STRING"".json"
	fi
done
cd ../


echo "The Items Detected Are: ${NAMES[*]}"
