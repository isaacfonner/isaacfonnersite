find ./ -type f -exec sed -i 's/tag=ZMI.renderer/tag=ZMI.renderer/g' {} \;

find ./ -type f -exec sed -i 's/ZMI.in_range/ZMI.in_range/g' {} \;

find ./ -type f -exec sed -i 's/ZMI.loaded/ZMI.ZMI.loaded/g' {} \;
